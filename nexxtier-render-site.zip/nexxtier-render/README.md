# Nexxtier Solutions — Render-ready website

This is a standalone HTML/CSS/JS reconstruction based on the public Wix website's visible text and structure. It is **not a pixel-perfect export** of the Wix editor, and Wix-owned images, fonts, and portfolio items have not been copied. Compare with your Wix site and add your own assets before launch.

## Deploy
1. Create a GitHub repository and upload `index.html`, `styles.css`, `script.js`, and `render.yaml` to the repository root.
2. In Render, choose **New > Static Site** and connect that GitHub repository.
3. Set **Build Command** to `echo 'No build needed'` and **Publish Directory** to `.`. Deploy.
4. Render assigns an `onrender.com` URL. Preview and test before changing any domain settings.

## Contact form — action required
The form currently posts to FormSubmit for `hello@nexxtier.com` (the email shown on the public Wix site). The owner must verify the email when the first submission triggers FormSubmit verification. Until verification, submissions may not be delivered. Check spam folders and test end to end. To use another form provider, replace the `action` URL and adapt fields. Do not submit sensitive data via the form.

## Before launch
- Verify all service descriptions and testimonials are approved for publication.
- Replace placeholder portfolio panel with actual approved project images/content.
- Add your own logo, veteran-owned badge, photos and exact brand styling if desired.
- Test mobile layout, accessibility, form delivery, and any custom domain DNS.
- The existing `wixsite.com` subdomain cannot be pointed to Render. Use Render's subdomain or a domain you own.
